<ul class="sidebar-menu toggle-menu list-items">
    <li class="<?php echo e((request()->is('admin/dashboard*')) ? 'page-active' : ''); ?>"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
    <li class="<?php echo e((request()->is('admin/cities*')) ? 'page-active' : ''); ?>"><a href="<?php echo e(route('admin.cities')); ?>"><i class="la la-city mr-2"></i>Cities</a></li>
    <li class="<?php echo e((request()->is('admin/venues*')) ? 'page-active' : ''); ?>"><a href="<?php echo e(route('admin.venues')); ?>"><i class="la la-campground mr-2"></i>Venues</a></li>
    <li class="<?php echo e((request()->is('admin/booking*')) ? 'page-active' : ''); ?>"><a href="<?php echo e(route('admin.booking')); ?>"><i class="la la-shopping-cart mr-2"></i>Bookings</a></li>
    <li class="<?php echo e((request()->is('admin/customers*')) ? 'page-active' : ''); ?>"><a href="<?php echo e(route('admin.customers')); ?>"><i class="la la-users mr-2"></i>Customers</a></li>
    <li class="<?php echo e((request()->is('admin/comments*')) ? 'page-active' : ''); ?>"><a href="<?php echo e(route('admin.comments')); ?>"><i class="la la-star mr-2"></i>Comments</a></li>
</ul>
<?php /**PATH /home/moin/projects/skyline/resources/views/admin/partials/sidebar.blade.php ENDPATH**/ ?>