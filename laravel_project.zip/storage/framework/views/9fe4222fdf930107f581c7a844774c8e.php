<ul class="nav navbar-nav navbar-right">
    <li><a href="<?php echo e(route('index')); ?>" title="Home">Home</a></li>
    <li class="dropdown">
        <a href="" title="Venue Types" class="dropdown-toggle" data-toggle="dropdown">Venue Types<b class="caret"></b></a>
        <ul class="dropdown-menu icon-fa-caret-up submenu-hover">
            <li><a href="<?php echo e(route('venues', ['type' => 'type', 'param' => 'farmhouse'])); ?>" title="Farm Houses">Farm Houses</a></li>
            <li><a href="<?php echo e(route('venues', ['type' => 'type', 'param' => 'banquet'])); ?>" title="Banquet Halls">Banquet Halls</a></li>
        </ul>
    </li>
    <li class="dropdown">
        <a href="" title="Locations" class="dropdown-toggle" data-toggle="dropdown">Locations<b class="caret"></b></a>
        <ul class="dropdown-menu icon-fa-caret-up submenu-hover">
            <?php $__currentLoopData = \App\Models\City::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('venues', ['type' => 'city', 'param' => $city->title])); ?>" title="<?php echo e($city->title); ?>"><?php echo e($city->title); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
    <li><a href="<?php echo e(route('gallery')); ?>" title="Gallery">Gallery</a></li>
    <li><a href="<?php echo e(route('about-us')); ?>" title="About Us">About</a></li>
    <li><a href="<?php echo e(route('contact-us')); ?>" title="Contact Us">Contact</a></li>
</ul>
<?php /**PATH /home/moin/projects/skyline/resources/views/partials/menu.blade.php ENDPATH**/ ?>