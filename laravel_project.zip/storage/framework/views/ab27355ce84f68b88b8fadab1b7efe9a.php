<div class="d-flex align-items-center">
    <div class="author-img avatar-sm">
        <img src="<?php echo e(asset('admin/images/team9.jpg')); ?>" alt="testimonial image">
    </div>
    <div class="author-bio">
        <h4 class="author__title">Skyline</h4>
        <span class="author__meta">Welcome to Admin Panel</span>
    </div>
</div>
<?php /**PATH /home/moin/projects/skyline/resources/views/admin/partials/sidebar-top.blade.php ENDPATH**/ ?>