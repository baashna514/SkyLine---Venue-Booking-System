<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Skyline - Bookings List</title>
    <!-- Favicon -->
    <link rel="icon" href="images/favicon.png">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&amp;display=swap" rel="stylesheet">

    <!-- Template CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/line-awesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/daterangepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/animated-headline.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/jquery-ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">
</head>
<body class="section-bg">
<!-- start cssload-loader -->
<div class="preloader" id="preloader">
    <div class="loader">
        <svg class="spinner" viewBox="0 0 50 50">
            <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
        </svg>
    </div>
</div>
<!-- end cssload-loader -->

<!-- ================================
       START USER CANVAS MENU
================================= -->
<div class="user-canvas-container">
    <div class="side-menu-close">
        <i class="la la-times"></i>
    </div><!-- end menu-toggler -->
    <?php echo $__env->make('admin.partials.mobile-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><!-- end user-canvas-container -->
<!-- ================================
       END USER CANVAS MENU
================================= -->

<!-- ================================
       START DASHBOARD NAV
================================= -->
<div class="sidebar-nav sidebar--nav">
    <div class="sidebar-nav-body">
        <div class="side-menu-close">
            <i class="la la-times"></i>
        </div><!-- end menu-toggler -->
        <div class="author-content">
            <?php echo $__env->make('admin.partials.sidebar-top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="sidebar-menu-wrap">
            <?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div><!-- end sidebar-menu-wrap -->
    </div>
</div><!-- end sidebar-nav -->
<!-- ================================
       END DASHBOARD NAV
================================= -->

<!-- ================================
    START DASHBOARD AREA
================================= -->
<section class="dashboard-area">
    <?php echo $__env->make('admin.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="dashboard-content-wrap">
        <div class="dashboard-bread dashboard--bread dashboard-bread-2">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="breadcrumb-content">
                            <div class="section-heading">
                                <h2 class="sec__title font-size-30 text-white">Bookings</h2>
                            </div>
                        </div><!-- end breadcrumb-content -->
                    </div><!-- end col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="breadcrumb-list text-right">
                            <ul class="list-items">
                                <li><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-white">Home</a></li>
                                <li>Bookings</li>
                            </ul>
                        </div><!-- end breadcrumb-list -->
                    </div><!-- end col-lg-6 -->
                    <?php echo $__env->make('admin.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div><!-- end row -->
            </div>
        </div><!-- end dashboard-bread -->
        <div class="dashboard-main-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-box">
                            <div class="form-title-wrap">
                                <div class="d-flex align-items-center justify-content-between">
                                    <h3 class="title">Booking Results</h3>
                                </div>
                            </div>
                            <div class="form-content pb-2">
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card-item card-item-list card-item--list">
                                    <div class="card-img">
                                        <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($booking->venue->thumbnail)); ?>" alt="hotel-img">
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex align-items-center">
                                            <h3 class="card-title"><?php echo e($booking->venue->title); ?></h3>
                                            <?php if($booking->status == 'approved'): ?>
                                                <span class="badge badge-success text-white ml-2"><?php echo e(ucfirst($booking->status)); ?></span>
                                            <?php elseif($booking->status == 'cancel'): ?>
                                                <span class="badge badge-danger text-white ml-2"><?php echo e(ucfirst($booking->status)); ?></span>
                                            <?php else: ?>
                                                <span class="badge badge-warning text-white ml-2"><?php echo e(ucfirst($booking->status)); ?></span>
                                            <?php endif; ?>
                                        </div>
                                       <ul class="list-items list-items-2 pt-2 pb-3">
                                           <li><span>Booking date:</span><?php echo e($booking->booking_date); ?></li>
                                           <li><span>Event date:</span><?php echo e($booking->function_date); ?></li>
                                           <li><span>Booking details:</span> <?php echo e($booking->persons); ?> People</li>
                                           <li><span>Client:</span> <?php echo e($booking->customer->name); ?></li>
                                           <li><span>Phone:</span> <?php echo e($booking->customer->phone); ?></li>
                                           <li><span>City:</span> <?php echo e($booking->customer->city); ?></li>
                                       </ul>



                                    </div>
                                    <div class="action-btns">
                                        <a href="<?php echo e(route('admin.booking.change-status', ['id' => $booking->id, 'status' => 'approved'])); ?>" class="theme-btn theme-btn-small mr-2"><i class="la la-check-circle mr-1"></i>Approve</a>
                                        <a href="<?php echo e(route('admin.booking.change-status', ['id' => $booking->id, 'status' => 'cancel'])); ?>" class="theme-btn theme-btn-small"><i class="la la-times mr-1"></i>Cancel</a>
                                    </div>
                                </div><!-- end card-item -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div><!-- end form-box -->
                    </div><!-- end col-lg-12 -->
                </div><!-- end row -->
                <div class="row">
                    <div class="col-lg-12">
                        <nav aria-label="Page navigation example">
                            <?php echo $__env->make('admin.partials.pagination', ['elements' => $bookings], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </nav>
                    </div>
                </div>
                <div class="border-top mt-5"></div>
                <div class="row align-items-center">
                    <?php echo $__env->make('admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div><!-- end row -->
            </div><!-- end container-fluid -->
        </div><!-- end dashboard-main-content -->
    </div><!-- end dashboard-content-wrap -->
</section><!-- end dashboard-area -->
<!-- ================================
    END DASHBOARD AREA
================================= -->

<!-- start scroll top -->
<div id="back-to-top">
    <i class="la la-angle-up" title="Go top"></i>
</div>
<!-- end scroll top -->

<!-- end modal-shared -->
<div class="modal-popup">
    <div class="modal fade" id="modalPopup" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title title" id="exampleModalLongTitle">Send Message</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="la la-close"></span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="contact-form-action">
                        <form method="post">
                            <div class="input-box">
                                <div class="form-group mb-0">
                                    <i class="la la-pencil form-icon"></i>
                                    <textarea class="message-control form-control" name="message" placeholder="Write message here..."></textarea>
                                </div>
                            </div>
                        </form>
                    </div><!-- end contact-form-action -->
                </div>
                <div class="modal-footer border-top-0 pt-0">
                    <button type="button" class="btn font-weight-bold font-size-15 color-text-2 mr-2" data-dismiss="modal">Cancel</button>
                    <button type="button" class="theme-btn theme-btn-small">Send Message</button>
                </div>
            </div>
        </div>
    </div>
</div><!-- end modal-popup -->

<!-- Template JS Files -->
<script src="<?php echo e(asset('admin/js/jquery-3.7.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/jquery.countTo.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/animated-headline.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/jquery.ripples-min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/moin/projects/skyline/resources/views/admin/admin-booking.blade.php ENDPATH**/ ?>