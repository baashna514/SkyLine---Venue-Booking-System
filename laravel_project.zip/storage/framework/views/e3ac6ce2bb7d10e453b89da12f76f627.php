<?php if(session('success')): ?>
    <div class="col-lg-12 mt-5">
        <div class="bg-light p-2 radius-round">
            <p class="text-success"><?php echo e(session('success')); ?></p>
        </div>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="col-lg-12 mt-5">
        <div class="bg-light p-2 radius-round">
            <p class="text-danger"><?php echo e(session('error')); ?></p>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /home/moin/projects/skyline/resources/views/admin/partials/messages.blade.php ENDPATH**/ ?>