(function ($) {
    "use strict";

    $('#fullscreen-slide-contain').superslides({
        play: 4000,
        pagination: false,
        animation_speed: 500,
        animation: 'fade'
    });

})(jQuery);