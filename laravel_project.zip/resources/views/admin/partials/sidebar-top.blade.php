<div class="d-flex align-items-center">
    <div class="author-img avatar-sm">
        <img src="{{ asset('admin/images/team9.jpg') }}" alt="testimonial image">
    </div>
    <div class="author-bio">
        <h4 class="author__title">Skyline</h4>
        <span class="author__meta">Welcome to Admin Panel</span>
    </div>
</div>
