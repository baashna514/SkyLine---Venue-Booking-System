<div class="col-lg-7">
    <div class="copy-right padding-top-30px">
        <p class="copy__desc">
            &copy; Copyright <a href="" class="text-primary">Skyline</a> 2024.
        </p>
    </div><!-- end copy-right -->
</div><!-- end col-lg-7 -->
<div class="col-lg-5">
    <div class="copy-right-content text-right padding-top-30px">
        <ul class="social-profile">
            <li><a href="#"><i class="lab la-facebook-f"></i></a></li>
            <li><a href="#"><i class="lab la-twitter"></i></a></li>
            <li><a href="#"><i class="lab la-instagram"></i></a></li>
            <li><a href="#"><i class="lab la-linkedin-in"></i></a></li>
        </ul>
    </div><!-- end copy-right-content -->
</div><!-- end col-lg-5 -->
